// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef LOGGING_DEMO__SRV__CONFIG_LOGGER_HPP_
#define LOGGING_DEMO__SRV__CONFIG_LOGGER_HPP_

#include "logging_demo/srv/detail/config_logger__struct.hpp"
#include "logging_demo/srv/detail/config_logger__builder.hpp"
#include "logging_demo/srv/detail/config_logger__traits.hpp"

#endif  // LOGGING_DEMO__SRV__CONFIG_LOGGER_HPP_
