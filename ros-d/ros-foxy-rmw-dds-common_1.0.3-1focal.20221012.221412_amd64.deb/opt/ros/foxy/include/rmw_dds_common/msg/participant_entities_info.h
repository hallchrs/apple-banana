// generated from rosidl_generator_c/resource/idl.h.em
// with input from rmw_dds_common:msg/ParticipantEntitiesInfo.idl
// generated code does not contain a copyright notice

#ifndef RMW_DDS_COMMON__MSG__PARTICIPANT_ENTITIES_INFO_H_
#define RMW_DDS_COMMON__MSG__PARTICIPANT_ENTITIES_INFO_H_

#include "rmw_dds_common/msg/detail/participant_entities_info__struct.h"
#include "rmw_dds_common/msg/detail/participant_entities_info__functions.h"
#include "rmw_dds_common/msg/detail/participant_entities_info__type_support.h"

#endif  // RMW_DDS_COMMON__MSG__PARTICIPANT_ENTITIES_INFO_H_
