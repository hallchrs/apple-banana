// generated from rosidl_generator_c/resource/idl.h.em
// with input from sensor_msgs:msg/CompressedImage.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_MSGS__MSG__COMPRESSED_IMAGE_H_
#define SENSOR_MSGS__MSG__COMPRESSED_IMAGE_H_

#include "sensor_msgs/msg/detail/compressed_image__struct.h"
#include "sensor_msgs/msg/detail/compressed_image__functions.h"
#include "sensor_msgs/msg/detail/compressed_image__type_support.h"

#endif  // SENSOR_MSGS__MSG__COMPRESSED_IMAGE_H_
