// generated from rosidl_typesupport_connext_c/resource/idl__rosidl_typesupport_connext_c.h.em
// with input from sensor_msgs:msg/CameraInfo.idl
// generated code does not contain a copyright notice


#ifndef SENSOR_MSGS__MSG__CAMERA_INFO__ROSIDL_TYPESUPPORT_CONNEXT_C_H_
#define SENSOR_MSGS__MSG__CAMERA_INFO__ROSIDL_TYPESUPPORT_CONNEXT_C_H_

#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "sensor_msgs/msg/rosidl_typesupport_connext_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_CONNEXT_C_PUBLIC_sensor_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_connext_c,
  sensor_msgs, msg,
  CameraInfo)();

#ifdef __cplusplus
}
#endif

#endif  // SENSOR_MSGS__MSG__CAMERA_INFO__ROSIDL_TYPESUPPORT_CONNEXT_C_H_
