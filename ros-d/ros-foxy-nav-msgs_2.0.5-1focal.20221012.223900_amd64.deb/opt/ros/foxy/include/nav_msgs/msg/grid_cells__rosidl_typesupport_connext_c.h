// generated from rosidl_typesupport_connext_c/resource/idl__rosidl_typesupport_connext_c.h.em
// with input from nav_msgs:msg/GridCells.idl
// generated code does not contain a copyright notice


#ifndef NAV_MSGS__MSG__GRID_CELLS__ROSIDL_TYPESUPPORT_CONNEXT_C_H_
#define NAV_MSGS__MSG__GRID_CELLS__ROSIDL_TYPESUPPORT_CONNEXT_C_H_

#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "nav_msgs/msg/rosidl_typesupport_connext_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_CONNEXT_C_PUBLIC_nav_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_connext_c,
  nav_msgs, msg,
  GridCells)();

#ifdef __cplusplus
}
#endif

#endif  // NAV_MSGS__MSG__GRID_CELLS__ROSIDL_TYPESUPPORT_CONNEXT_C_H_
