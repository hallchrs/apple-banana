/*
 * This file generated on line 754 of /build/atlas-mGOM49/atlas-3.10.3/build/..//tune/blas/ger/r2hgen.c
 */
#ifndef ATLAS_CR2KERNELS_H
   #define ATLAS_CR2KERNELS_H

void ATL_cger2k__900001
   (ATL_CINT, ATL_CINT, const float*, const float*, const float*,
    const float*, float*, ATL_CINT);
void ATL_cger2k__900001
   (ATL_CINT, ATL_CINT, const float*, const float*, const float*,
    const float*, float*, ATL_CINT);
void ATL_cger2k__900001
   (ATL_CINT, ATL_CINT, const float*, const float*, const float*,
    const float*, float*, ATL_CINT);
void ATL_cger2k__900001
   (ATL_CINT, ATL_CINT, const float*, const float*, const float*,
    const float*, float*, ATL_CINT);


#endif /* end guard around atlas_cr2kernels.h */
