/*
 * This file generated on line 399 of /build/atlas-mGOM49/atlas-3.10.3/build/..//tune/blas/gemv/mvnhgen.c
 */
#ifndef ATLAS_ZMVNKERNELS_H
   #define ATLAS_ZMVNKERNELS_H

void ATL_zmvnk__1(ATL_CINT, ATL_CINT, const double*, ATL_CINT, const double*, double*);
void ATL_zmvnk__1_b0(ATL_CINT, ATL_CINT, const double*, ATL_CINT, const double*, double*);
void ATL_zmvnk__900003(ATL_CINT, ATL_CINT, const double*, ATL_CINT, const double*, double*);
void ATL_zmvnk__900003_b0(ATL_CINT, ATL_CINT, const double*, ATL_CINT, const double*, double*);
void ATL_zmvnk__900003(ATL_CINT, ATL_CINT, const double*, ATL_CINT, const double*, double*);
void ATL_zmvnk__900003_b0(ATL_CINT, ATL_CINT, const double*, ATL_CINT, const double*, double*);
void ATL_zmvnk__900001(ATL_CINT, ATL_CINT, const double*, ATL_CINT, const double*, double*);
void ATL_zmvnk__900001_b0(ATL_CINT, ATL_CINT, const double*, ATL_CINT, const double*, double*);


#endif /* end guard around atlas_zmvnkernels.h */
