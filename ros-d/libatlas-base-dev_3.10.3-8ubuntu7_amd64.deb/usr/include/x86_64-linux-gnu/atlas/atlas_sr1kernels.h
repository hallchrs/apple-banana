/*
 * This file generated on line 730 of /build/atlas-mGOM49/atlas-3.10.3/build/..//tune/blas/ger/r1hgen.c
 */
#ifndef ATLAS_SR1KERNELS_H
   #define ATLAS_SR1KERNELS_H

void ATL_sgerk__900001
   (ATL_CINT, ATL_CINT, const float*, const float*, float*, ATL_CINT);
void ATL_sgerk__1
   (ATL_CINT, ATL_CINT, const float*, const float*, float*, ATL_CINT);
void ATL_sgerk__900002
   (ATL_CINT, ATL_CINT, const float*, const float*, float*, ATL_CINT);
void ATL_sgerk__900001
   (ATL_CINT, ATL_CINT, const float*, const float*, float*, ATL_CINT);


#endif /* end guard around atlas_sr1kernels.h */
