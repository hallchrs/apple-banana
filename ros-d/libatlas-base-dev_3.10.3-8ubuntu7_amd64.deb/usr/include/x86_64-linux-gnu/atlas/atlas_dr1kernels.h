/*
 * This file generated on line 730 of /build/atlas-mGOM49/atlas-3.10.3/build/..//tune/blas/ger/r1hgen.c
 */
#ifndef ATLAS_DR1KERNELS_H
   #define ATLAS_DR1KERNELS_H

void ATL_dgerk__900001
   (ATL_CINT, ATL_CINT, const double*, const double*, double*, ATL_CINT);
void ATL_dgerk__900002
   (ATL_CINT, ATL_CINT, const double*, const double*, double*, ATL_CINT);
void ATL_dgerk__900002
   (ATL_CINT, ATL_CINT, const double*, const double*, double*, ATL_CINT);
void ATL_dgerk__900001
   (ATL_CINT, ATL_CINT, const double*, const double*, double*, ATL_CINT);


#endif /* end guard around atlas_dr1kernels.h */
