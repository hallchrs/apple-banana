/*
 * This file generated on line 403 of /build/atlas-mGOM49/atlas-3.10.3/build/..//tune/blas/gemv/mvthgen.c
 */
#ifndef ATLAS_CMVTKERNELS_H
   #define ATLAS_CMVTKERNELS_H

void ATL_cmvtk__900001(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);
void ATL_cmvtk__900001_b0(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);
void ATL_cmvtk__900001(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);
void ATL_cmvtk__900001_b0(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);
void ATL_cmvtk__900001(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);
void ATL_cmvtk__900001_b0(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);
void ATL_cmvtk__900001(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);
void ATL_cmvtk__900001_b0(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);


#endif /* end guard around atlas_cmvtkernels.h */
