#ifndef ZXOVER_H
#define ZXOVER_H

#define ATL_3NB 144
#define NN_MNK_M 106032
#define NN_MNK_N 106032
#define NN_MNK_MN 23040
#define NN_MNK_K 69312
#define NN_MNK_GE 54872
#define NT_MNK_M 27648
#define NT_MNK_N 106032
#define NT_MNK_MN 23040
#define NT_MNK_K 106032
#define NT_MNK_GE 13824
#define TN_MNK_M 69312
#define TN_MNK_N 69312
#define TN_MNK_MN 69120
#define TN_MNK_K 106032
#define TN_MNK_GE 54872
#define TT_MNK_M 106032
#define TT_MNK_N 43200
#define TT_MNK_MN 34560
#define TT_MNK_K 69312
#define TT_MNK_GE 103823
#define C2R_K 301

#endif
