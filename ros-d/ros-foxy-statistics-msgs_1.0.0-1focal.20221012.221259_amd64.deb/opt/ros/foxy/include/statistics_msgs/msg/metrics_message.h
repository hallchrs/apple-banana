// generated from rosidl_generator_c/resource/idl.h.em
// with input from statistics_msgs:msg/MetricsMessage.idl
// generated code does not contain a copyright notice

#ifndef STATISTICS_MSGS__MSG__METRICS_MESSAGE_H_
#define STATISTICS_MSGS__MSG__METRICS_MESSAGE_H_

#include "statistics_msgs/msg/detail/metrics_message__struct.h"
#include "statistics_msgs/msg/detail/metrics_message__functions.h"
#include "statistics_msgs/msg/detail/metrics_message__type_support.h"

#endif  // STATISTICS_MSGS__MSG__METRICS_MESSAGE_H_
