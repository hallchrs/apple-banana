// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef STATISTICS_MSGS__MSG__STATISTIC_DATA_POINT_HPP_
#define STATISTICS_MSGS__MSG__STATISTIC_DATA_POINT_HPP_

#include "statistics_msgs/msg/detail/statistic_data_point__struct.hpp"
#include "statistics_msgs/msg/detail/statistic_data_point__builder.hpp"
#include "statistics_msgs/msg/detail/statistic_data_point__traits.hpp"

#endif  // STATISTICS_MSGS__MSG__STATISTIC_DATA_POINT_HPP_
