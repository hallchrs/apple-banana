// generated from rosidl_typesupport_connext_c/resource/idl__rosidl_typesupport_connext_c.h.em
// with input from statistics_msgs:msg/MetricsMessage.idl
// generated code does not contain a copyright notice


#ifndef STATISTICS_MSGS__MSG__METRICS_MESSAGE__ROSIDL_TYPESUPPORT_CONNEXT_C_H_
#define STATISTICS_MSGS__MSG__METRICS_MESSAGE__ROSIDL_TYPESUPPORT_CONNEXT_C_H_

#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "statistics_msgs/msg/rosidl_typesupport_connext_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_CONNEXT_C_PUBLIC_statistics_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_connext_c,
  statistics_msgs, msg,
  MetricsMessage)();

#ifdef __cplusplus
}
#endif

#endif  // STATISTICS_MSGS__MSG__METRICS_MESSAGE__ROSIDL_TYPESUPPORT_CONNEXT_C_H_
