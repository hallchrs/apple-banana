// generated from rosidl_generator_c/resource/idl.h.em
// with input from statistics_msgs:msg/StatisticDataPoint.idl
// generated code does not contain a copyright notice

#ifndef STATISTICS_MSGS__MSG__STATISTIC_DATA_POINT_H_
#define STATISTICS_MSGS__MSG__STATISTIC_DATA_POINT_H_

#include "statistics_msgs/msg/detail/statistic_data_point__struct.h"
#include "statistics_msgs/msg/detail/statistic_data_point__functions.h"
#include "statistics_msgs/msg/detail/statistic_data_point__type_support.h"

#endif  // STATISTICS_MSGS__MSG__STATISTIC_DATA_POINT_H_
