// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PENDULUM_MSGS__MSG__RTTEST_RESULTS_HPP_
#define PENDULUM_MSGS__MSG__RTTEST_RESULTS_HPP_

#include "pendulum_msgs/msg/detail/rttest_results__struct.hpp"
#include "pendulum_msgs/msg/detail/rttest_results__builder.hpp"
#include "pendulum_msgs/msg/detail/rttest_results__traits.hpp"

#endif  // PENDULUM_MSGS__MSG__RTTEST_RESULTS_HPP_
