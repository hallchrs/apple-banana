// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PENDULUM_MSGS__MSG__JOINT_STATE_HPP_
#define PENDULUM_MSGS__MSG__JOINT_STATE_HPP_

#include "pendulum_msgs/msg/detail/joint_state__struct.hpp"
#include "pendulum_msgs/msg/detail/joint_state__builder.hpp"
#include "pendulum_msgs/msg/detail/joint_state__traits.hpp"

#endif  // PENDULUM_MSGS__MSG__JOINT_STATE_HPP_
