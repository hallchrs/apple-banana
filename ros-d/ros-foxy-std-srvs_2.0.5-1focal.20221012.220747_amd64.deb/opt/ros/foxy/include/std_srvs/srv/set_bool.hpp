// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef STD_SRVS__SRV__SET_BOOL_HPP_
#define STD_SRVS__SRV__SET_BOOL_HPP_

#include "std_srvs/srv/detail/set_bool__struct.hpp"
#include "std_srvs/srv/detail/set_bool__builder.hpp"
#include "std_srvs/srv/detail/set_bool__traits.hpp"

#endif  // STD_SRVS__SRV__SET_BOOL_HPP_
