// generated from rosidl_generator_c/resource/idl.h.em
// with input from std_msgs:msg/Byte.idl
// generated code does not contain a copyright notice

#ifndef STD_MSGS__MSG__BYTE_H_
#define STD_MSGS__MSG__BYTE_H_

#include "std_msgs/msg/detail/byte__struct.h"
#include "std_msgs/msg/detail/byte__functions.h"
#include "std_msgs/msg/detail/byte__type_support.h"

#endif  // STD_MSGS__MSG__BYTE_H_
