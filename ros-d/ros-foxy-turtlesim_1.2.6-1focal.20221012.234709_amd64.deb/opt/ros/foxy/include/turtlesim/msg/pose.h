// generated from rosidl_generator_c/resource/idl.h.em
// with input from turtlesim:msg/Pose.idl
// generated code does not contain a copyright notice

#ifndef TURTLESIM__MSG__POSE_H_
#define TURTLESIM__MSG__POSE_H_

#include "turtlesim/msg/detail/pose__struct.h"
#include "turtlesim/msg/detail/pose__functions.h"
#include "turtlesim/msg/detail/pose__type_support.h"

#endif  // TURTLESIM__MSG__POSE_H_
