// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TURTLESIM__ACTION__ROTATE_ABSOLUTE_HPP_
#define TURTLESIM__ACTION__ROTATE_ABSOLUTE_HPP_

#include "turtlesim/action/detail/rotate_absolute__struct.hpp"
#include "turtlesim/action/detail/rotate_absolute__builder.hpp"
#include "turtlesim/action/detail/rotate_absolute__traits.hpp"

#endif  // TURTLESIM__ACTION__ROTATE_ABSOLUTE_HPP_
