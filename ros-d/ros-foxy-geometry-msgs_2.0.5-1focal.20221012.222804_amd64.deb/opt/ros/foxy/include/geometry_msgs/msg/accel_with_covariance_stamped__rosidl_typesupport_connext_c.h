// generated from rosidl_typesupport_connext_c/resource/idl__rosidl_typesupport_connext_c.h.em
// with input from geometry_msgs:msg/AccelWithCovarianceStamped.idl
// generated code does not contain a copyright notice


#ifndef GEOMETRY_MSGS__MSG__ACCEL_WITH_COVARIANCE_STAMPED__ROSIDL_TYPESUPPORT_CONNEXT_C_H_
#define GEOMETRY_MSGS__MSG__ACCEL_WITH_COVARIANCE_STAMPED__ROSIDL_TYPESUPPORT_CONNEXT_C_H_

#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "geometry_msgs/msg/rosidl_typesupport_connext_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_CONNEXT_C_PUBLIC_geometry_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_connext_c,
  geometry_msgs, msg,
  AccelWithCovarianceStamped)();

#ifdef __cplusplus
}
#endif

#endif  // GEOMETRY_MSGS__MSG__ACCEL_WITH_COVARIANCE_STAMPED__ROSIDL_TYPESUPPORT_CONNEXT_C_H_
