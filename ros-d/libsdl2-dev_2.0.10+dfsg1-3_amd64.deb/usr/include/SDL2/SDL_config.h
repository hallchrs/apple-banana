/* Debian-specific indirection to an architecture-specific copy of
 * SDL_config.h in one of the compiler's default include directories.
 * Please do not include _real_SDL_config.h directly. */
#include <SDL2/_real_SDL_config.h>
