// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef LIBSTATISTICS_COLLECTOR__MSG__DUMMY_MESSAGE_HPP_
#define LIBSTATISTICS_COLLECTOR__MSG__DUMMY_MESSAGE_HPP_

#include "libstatistics_collector/msg/detail/dummy_message__struct.hpp"
#include "libstatistics_collector/msg/detail/dummy_message__builder.hpp"
#include "libstatistics_collector/msg/detail/dummy_message__traits.hpp"

#endif  // LIBSTATISTICS_COLLECTOR__MSG__DUMMY_MESSAGE_HPP_
