// generated from rosidl_generator_c/resource/idl.h.em
// with input from libstatistics_collector:msg/DummyMessage.idl
// generated code does not contain a copyright notice

#ifndef LIBSTATISTICS_COLLECTOR__MSG__DUMMY_MESSAGE_H_
#define LIBSTATISTICS_COLLECTOR__MSG__DUMMY_MESSAGE_H_

#include "libstatistics_collector/msg/detail/dummy_message__struct.h"
#include "libstatistics_collector/msg/detail/dummy_message__functions.h"
#include "libstatistics_collector/msg/detail/dummy_message__type_support.h"

#endif  // LIBSTATISTICS_COLLECTOR__MSG__DUMMY_MESSAGE_H_
