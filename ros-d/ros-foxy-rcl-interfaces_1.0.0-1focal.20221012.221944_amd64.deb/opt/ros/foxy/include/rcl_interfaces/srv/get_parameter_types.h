// generated from rosidl_generator_c/resource/idl.h.em
// with input from rcl_interfaces:srv/GetParameterTypes.idl
// generated code does not contain a copyright notice

#ifndef RCL_INTERFACES__SRV__GET_PARAMETER_TYPES_H_
#define RCL_INTERFACES__SRV__GET_PARAMETER_TYPES_H_

#include "rcl_interfaces/srv/detail/get_parameter_types__struct.h"
#include "rcl_interfaces/srv/detail/get_parameter_types__functions.h"
#include "rcl_interfaces/srv/detail/get_parameter_types__type_support.h"

#endif  // RCL_INTERFACES__SRV__GET_PARAMETER_TYPES_H_
