# generated from ros_environment/env-hooks/1.ros_localhost_only.sh.in

if [ -n "$ROS_LOCALHOST_ONLY" ]; then
  export ROS_LOCALHOST_ONLY=0
fi
