// generated from rosidl_generator_c/resource/idl.h.em
// with input from pcl_msgs:msg/PointIndices.idl
// generated code does not contain a copyright notice

#ifndef PCL_MSGS__MSG__POINT_INDICES_H_
#define PCL_MSGS__MSG__POINT_INDICES_H_

#include "pcl_msgs/msg/detail/point_indices__struct.h"
#include "pcl_msgs/msg/detail/point_indices__functions.h"
#include "pcl_msgs/msg/detail/point_indices__type_support.h"

#endif  // PCL_MSGS__MSG__POINT_INDICES_H_
