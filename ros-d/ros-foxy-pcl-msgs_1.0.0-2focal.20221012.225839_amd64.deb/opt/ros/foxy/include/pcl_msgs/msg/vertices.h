// generated from rosidl_generator_c/resource/idl.h.em
// with input from pcl_msgs:msg/Vertices.idl
// generated code does not contain a copyright notice

#ifndef PCL_MSGS__MSG__VERTICES_H_
#define PCL_MSGS__MSG__VERTICES_H_

#include "pcl_msgs/msg/detail/vertices__struct.h"
#include "pcl_msgs/msg/detail/vertices__functions.h"
#include "pcl_msgs/msg/detail/vertices__type_support.h"

#endif  // PCL_MSGS__MSG__VERTICES_H_
