// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PCL_MSGS__MSG__MODEL_COEFFICIENTS_HPP_
#define PCL_MSGS__MSG__MODEL_COEFFICIENTS_HPP_

#include "pcl_msgs/msg/detail/model_coefficients__struct.hpp"
#include "pcl_msgs/msg/detail/model_coefficients__builder.hpp"
#include "pcl_msgs/msg/detail/model_coefficients__traits.hpp"

#endif  // PCL_MSGS__MSG__MODEL_COEFFICIENTS_HPP_
