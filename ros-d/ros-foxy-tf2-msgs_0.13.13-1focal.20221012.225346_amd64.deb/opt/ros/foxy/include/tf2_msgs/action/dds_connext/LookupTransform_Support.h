
/*
WARNING: THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.

This file was generated from LookupTransform_.idl using "rtiddsgen".
The rtiddsgen tool is part of the RTI Connext distribution.
For more information, type 'rtiddsgen -help' at a command shell
or consult the RTI Connext manual.
*/

#ifndef LookupTransform_Support_1421503919_h
#define LookupTransform_Support_1421503919_h

/* Uses */
#include "LookupTransform_.h"

#ifndef ndds_cpp_h
#include "ndds/ndds_cpp.h"
#endif

#if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)

class __declspec(dllimport) DDSTypeSupport;
class __declspec(dllimport) DDSDataWriter;
class __declspec(dllimport) DDSDataReader;

#endif

namespace tf2_msgs {
    namespace action {
        namespace dds_ {
            /* ========================================================================= */
            /**
            Uses:     T

            Defines:  TTypeSupport, TDataWriter, TDataReader

            Organized using the well-documented "Generics Pattern" for
            implementing generics in C and C++.
            */

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, start exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport __declspec(dllexport)

            #endif

            DDS_TYPESUPPORT_CPP(
                LookupTransform_Goal_TypeSupport, 
                LookupTransform_Goal_);

            DDS_DATAWRITER_CPP(LookupTransform_Goal_DataWriter, LookupTransform_Goal_);
            DDS_DATAREADER_CPP(LookupTransform_Goal_DataReader, LookupTransform_Goal_Seq, LookupTransform_Goal_);

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, stop exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport
            #endif
        } /* namespace dds_  */
    } /* namespace action  */
} /* namespace tf2_msgs  */
namespace tf2_msgs {
    namespace action {
        namespace dds_ {
            /* ========================================================================= */
            /**
            Uses:     T

            Defines:  TTypeSupport, TDataWriter, TDataReader

            Organized using the well-documented "Generics Pattern" for
            implementing generics in C and C++.
            */

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, start exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport __declspec(dllexport)

            #endif

            DDS_TYPESUPPORT_CPP(
                LookupTransform_SendGoal_Request_TypeSupport, 
                LookupTransform_SendGoal_Request_);

            DDS_DATAWRITER_CPP(LookupTransform_SendGoal_Request_DataWriter, LookupTransform_SendGoal_Request_);
            DDS_DATAREADER_CPP(LookupTransform_SendGoal_Request_DataReader, LookupTransform_SendGoal_Request_Seq, LookupTransform_SendGoal_Request_);

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, stop exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport
            #endif
        } /* namespace dds_  */
    } /* namespace action  */
} /* namespace tf2_msgs  */
namespace tf2_msgs {
    namespace action {
        namespace dds_ {
            /* ========================================================================= */
            /**
            Uses:     T

            Defines:  TTypeSupport, TDataWriter, TDataReader

            Organized using the well-documented "Generics Pattern" for
            implementing generics in C and C++.
            */

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, start exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport __declspec(dllexport)

            #endif

            DDS_TYPESUPPORT_CPP(
                LookupTransform_SendGoal_Response_TypeSupport, 
                LookupTransform_SendGoal_Response_);

            DDS_DATAWRITER_CPP(LookupTransform_SendGoal_Response_DataWriter, LookupTransform_SendGoal_Response_);
            DDS_DATAREADER_CPP(LookupTransform_SendGoal_Response_DataReader, LookupTransform_SendGoal_Response_Seq, LookupTransform_SendGoal_Response_);

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, stop exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport
            #endif
        } /* namespace dds_  */
    } /* namespace action  */
} /* namespace tf2_msgs  */
namespace tf2_msgs {
    namespace action {
        namespace dds_ {
            /* ========================================================================= */
            /**
            Uses:     T

            Defines:  TTypeSupport, TDataWriter, TDataReader

            Organized using the well-documented "Generics Pattern" for
            implementing generics in C and C++.
            */

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, start exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport __declspec(dllexport)

            #endif

            DDS_TYPESUPPORT_CPP(
                LookupTransform_Result_TypeSupport, 
                LookupTransform_Result_);

            DDS_DATAWRITER_CPP(LookupTransform_Result_DataWriter, LookupTransform_Result_);
            DDS_DATAREADER_CPP(LookupTransform_Result_DataReader, LookupTransform_Result_Seq, LookupTransform_Result_);

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, stop exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport
            #endif
        } /* namespace dds_  */
    } /* namespace action  */
} /* namespace tf2_msgs  */
namespace tf2_msgs {
    namespace action {
        namespace dds_ {
            /* ========================================================================= */
            /**
            Uses:     T

            Defines:  TTypeSupport, TDataWriter, TDataReader

            Organized using the well-documented "Generics Pattern" for
            implementing generics in C and C++.
            */

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, start exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport __declspec(dllexport)

            #endif

            DDS_TYPESUPPORT_CPP(
                LookupTransform_GetResult_Request_TypeSupport, 
                LookupTransform_GetResult_Request_);

            DDS_DATAWRITER_CPP(LookupTransform_GetResult_Request_DataWriter, LookupTransform_GetResult_Request_);
            DDS_DATAREADER_CPP(LookupTransform_GetResult_Request_DataReader, LookupTransform_GetResult_Request_Seq, LookupTransform_GetResult_Request_);

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, stop exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport
            #endif
        } /* namespace dds_  */
    } /* namespace action  */
} /* namespace tf2_msgs  */
namespace tf2_msgs {
    namespace action {
        namespace dds_ {
            /* ========================================================================= */
            /**
            Uses:     T

            Defines:  TTypeSupport, TDataWriter, TDataReader

            Organized using the well-documented "Generics Pattern" for
            implementing generics in C and C++.
            */

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, start exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport __declspec(dllexport)

            #endif

            DDS_TYPESUPPORT_CPP(
                LookupTransform_GetResult_Response_TypeSupport, 
                LookupTransform_GetResult_Response_);

            DDS_DATAWRITER_CPP(LookupTransform_GetResult_Response_DataWriter, LookupTransform_GetResult_Response_);
            DDS_DATAREADER_CPP(LookupTransform_GetResult_Response_DataReader, LookupTransform_GetResult_Response_Seq, LookupTransform_GetResult_Response_);

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, stop exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport
            #endif
        } /* namespace dds_  */
    } /* namespace action  */
} /* namespace tf2_msgs  */
namespace tf2_msgs {
    namespace action {
        namespace dds_ {
            /* ========================================================================= */
            /**
            Uses:     T

            Defines:  TTypeSupport, TDataWriter, TDataReader

            Organized using the well-documented "Generics Pattern" for
            implementing generics in C and C++.
            */

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, start exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport __declspec(dllexport)

            #endif

            DDS_TYPESUPPORT_CPP(
                LookupTransform_Feedback_TypeSupport, 
                LookupTransform_Feedback_);

            DDS_DATAWRITER_CPP(LookupTransform_Feedback_DataWriter, LookupTransform_Feedback_);
            DDS_DATAREADER_CPP(LookupTransform_Feedback_DataReader, LookupTransform_Feedback_Seq, LookupTransform_Feedback_);

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, stop exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport
            #endif
        } /* namespace dds_  */
    } /* namespace action  */
} /* namespace tf2_msgs  */
namespace tf2_msgs {
    namespace action {
        namespace dds_ {
            /* ========================================================================= */
            /**
            Uses:     T

            Defines:  TTypeSupport, TDataWriter, TDataReader

            Organized using the well-documented "Generics Pattern" for
            implementing generics in C and C++.
            */

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, start exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport __declspec(dllexport)

            #endif

            DDS_TYPESUPPORT_CPP(
                LookupTransform_FeedbackMessage_TypeSupport, 
                LookupTransform_FeedbackMessage_);

            DDS_DATAWRITER_CPP(LookupTransform_FeedbackMessage_DataWriter, LookupTransform_FeedbackMessage_);
            DDS_DATAREADER_CPP(LookupTransform_FeedbackMessage_DataReader, LookupTransform_FeedbackMessage_Seq, LookupTransform_FeedbackMessage_);

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, stop exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport
            #endif
        } /* namespace dds_  */
    } /* namespace action  */
} /* namespace tf2_msgs  */

#endif  /* LookupTransform_Support_1421503919_h */

