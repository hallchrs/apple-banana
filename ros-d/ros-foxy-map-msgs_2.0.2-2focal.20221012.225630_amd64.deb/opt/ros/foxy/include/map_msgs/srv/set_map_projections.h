// generated from rosidl_generator_c/resource/idl.h.em
// with input from map_msgs:srv/SetMapProjections.idl
// generated code does not contain a copyright notice

#ifndef MAP_MSGS__SRV__SET_MAP_PROJECTIONS_H_
#define MAP_MSGS__SRV__SET_MAP_PROJECTIONS_H_

#include "map_msgs/srv/detail/set_map_projections__struct.h"
#include "map_msgs/srv/detail/set_map_projections__functions.h"
#include "map_msgs/srv/detail/set_map_projections__type_support.h"

#endif  // MAP_MSGS__SRV__SET_MAP_PROJECTIONS_H_
