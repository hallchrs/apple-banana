// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MAP_MSGS__SRV__GET_MAP_ROI_HPP_
#define MAP_MSGS__SRV__GET_MAP_ROI_HPP_

#include "map_msgs/srv/detail/get_map_roi__struct.hpp"
#include "map_msgs/srv/detail/get_map_roi__builder.hpp"
#include "map_msgs/srv/detail/get_map_roi__traits.hpp"

#endif  // MAP_MSGS__SRV__GET_MAP_ROI_HPP_
