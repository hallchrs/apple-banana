// generated from rosidl_generator_c/resource/idl.h.em
// with input from map_msgs:srv/ProjectedMapsInfo.idl
// generated code does not contain a copyright notice

#ifndef MAP_MSGS__SRV__PROJECTED_MAPS_INFO_H_
#define MAP_MSGS__SRV__PROJECTED_MAPS_INFO_H_

#include "map_msgs/srv/detail/projected_maps_info__struct.h"
#include "map_msgs/srv/detail/projected_maps_info__functions.h"
#include "map_msgs/srv/detail/projected_maps_info__type_support.h"

#endif  // MAP_MSGS__SRV__PROJECTED_MAPS_INFO_H_
