// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MAP_MSGS__MSG__POINT_CLOUD2_UPDATE_HPP_
#define MAP_MSGS__MSG__POINT_CLOUD2_UPDATE_HPP_

#include "map_msgs/msg/detail/point_cloud2_update__struct.hpp"
#include "map_msgs/msg/detail/point_cloud2_update__builder.hpp"
#include "map_msgs/msg/detail/point_cloud2_update__traits.hpp"

#endif  // MAP_MSGS__MSG__POINT_CLOUD2_UPDATE_HPP_
