// generated from rosidl_typesupport_connext_c/resource/idl__rosidl_typesupport_connext_c.h.em
// with input from map_msgs:msg/OccupancyGridUpdate.idl
// generated code does not contain a copyright notice


#ifndef MAP_MSGS__MSG__OCCUPANCY_GRID_UPDATE__ROSIDL_TYPESUPPORT_CONNEXT_C_H_
#define MAP_MSGS__MSG__OCCUPANCY_GRID_UPDATE__ROSIDL_TYPESUPPORT_CONNEXT_C_H_

#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "map_msgs/msg/rosidl_typesupport_connext_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_CONNEXT_C_PUBLIC_map_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_connext_c,
  map_msgs, msg,
  OccupancyGridUpdate)();

#ifdef __cplusplus
}
#endif

#endif  // MAP_MSGS__MSG__OCCUPANCY_GRID_UPDATE__ROSIDL_TYPESUPPORT_CONNEXT_C_H_
