// generated from rosidl_generator_c/resource/idl.h.em
// with input from rosgraph_msgs:msg/Clock.idl
// generated code does not contain a copyright notice

#ifndef ROSGRAPH_MSGS__MSG__CLOCK_H_
#define ROSGRAPH_MSGS__MSG__CLOCK_H_

#include "rosgraph_msgs/msg/detail/clock__struct.h"
#include "rosgraph_msgs/msg/detail/clock__functions.h"
#include "rosgraph_msgs/msg/detail/clock__type_support.h"

#endif  // ROSGRAPH_MSGS__MSG__CLOCK_H_
