// generated from rosidl_generator_c/resource/idl.h.em
// with input from lifecycle_msgs:msg/TransitionEvent.idl
// generated code does not contain a copyright notice

#ifndef LIFECYCLE_MSGS__MSG__TRANSITION_EVENT_H_
#define LIFECYCLE_MSGS__MSG__TRANSITION_EVENT_H_

#include "lifecycle_msgs/msg/detail/transition_event__struct.h"
#include "lifecycle_msgs/msg/detail/transition_event__functions.h"
#include "lifecycle_msgs/msg/detail/transition_event__type_support.h"

#endif  // LIFECYCLE_MSGS__MSG__TRANSITION_EVENT_H_
