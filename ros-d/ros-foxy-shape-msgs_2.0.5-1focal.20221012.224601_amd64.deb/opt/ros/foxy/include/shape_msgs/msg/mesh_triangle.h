// generated from rosidl_generator_c/resource/idl.h.em
// with input from shape_msgs:msg/MeshTriangle.idl
// generated code does not contain a copyright notice

#ifndef SHAPE_MSGS__MSG__MESH_TRIANGLE_H_
#define SHAPE_MSGS__MSG__MESH_TRIANGLE_H_

#include "shape_msgs/msg/detail/mesh_triangle__struct.h"
#include "shape_msgs/msg/detail/mesh_triangle__functions.h"
#include "shape_msgs/msg/detail/mesh_triangle__type_support.h"

#endif  // SHAPE_MSGS__MSG__MESH_TRIANGLE_H_
