// generated from rosidl_generator_c/resource/idl.h.em
// with input from shape_msgs:msg/SolidPrimitive.idl
// generated code does not contain a copyright notice

#ifndef SHAPE_MSGS__MSG__SOLID_PRIMITIVE_H_
#define SHAPE_MSGS__MSG__SOLID_PRIMITIVE_H_

#include "shape_msgs/msg/detail/solid_primitive__struct.h"
#include "shape_msgs/msg/detail/solid_primitive__functions.h"
#include "shape_msgs/msg/detail/solid_primitive__type_support.h"

#endif  // SHAPE_MSGS__MSG__SOLID_PRIMITIVE_H_
