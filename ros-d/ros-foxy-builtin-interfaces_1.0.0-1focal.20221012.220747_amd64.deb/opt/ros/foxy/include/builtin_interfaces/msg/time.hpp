// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef BUILTIN_INTERFACES__MSG__TIME_HPP_
#define BUILTIN_INTERFACES__MSG__TIME_HPP_

#include "builtin_interfaces/msg/detail/time__struct.hpp"
#include "builtin_interfaces/msg/detail/time__builder.hpp"
#include "builtin_interfaces/msg/detail/time__traits.hpp"

#endif  // BUILTIN_INTERFACES__MSG__TIME_HPP_
